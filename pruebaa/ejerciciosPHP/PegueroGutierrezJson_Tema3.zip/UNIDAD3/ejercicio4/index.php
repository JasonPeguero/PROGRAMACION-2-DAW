<?php

require_once 'datos.php';

$total = count(obtenerProductos());
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ejercicio4</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
<div class="container-sm">
    <h1 class="mb-4">Gestión de productos</h1>



    <div class="d-flex gap-3">
        <a href="productos.php">buscar productos</a>
        <a href="nuevo.php">Nuevo producto</a>
    </div>
</div>
</body>
</html>